<?php echo e($slot); ?>

<?php /**PATH C:\Users\youco\Desktop\hssab-sabon\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>