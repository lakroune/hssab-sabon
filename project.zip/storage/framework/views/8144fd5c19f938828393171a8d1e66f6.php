<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>HS - Financial Control</title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=plus-jakarta-sans:400,500,600,700&display=swap" rel="stylesheet" />

    <!-- Scripts & Styles -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <style>
        /* منع وميض العناصر قبل تحميل Alpine */
        [x-cloak] { display: none !important; }
        
        /* فرض الحواف الحادة على كل المكونات */
        * { border-radius: 0 !important; }
        
        /* تحسين مظهر السكرول بار ليتناسب مع التصميم الداكن */
        ::-webkit-scrollbar { width: 8px; }
        ::-webkit-scrollbar-track { background: #0f172a; }
        ::-webkit-scrollbar-thumb { background: #1e293b; border-radius: 0; }
        ::-webkit-scrollbar-thumb:hover { background: #334155; }
    </style>
</head>
<body class="font-sans antialiased bg-[#0f172a] text-slate-200">

    <div class="min-h-screen">
        <!-- Navigation -->
        <?php echo $__env->make('layouts.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <!-- Page Heading -->
        <?php if(isset($header)): ?>
            <header class="bg-slate-900/50 border-b border-slate-800 backdrop-blur-md">
                <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
                    <?php echo e($header); ?>

                </div>
            </header>
        <?php endif; ?>

        <!-- Main Content Slot -->
        <main>
            <?php echo e($slot); ?>

        </main>
    </div>

</body>
</html><?php /**PATH C:\Users\youco\Desktop\hssab-sabon\resources\views/layouts/app.blade.php ENDPATH**/ ?>