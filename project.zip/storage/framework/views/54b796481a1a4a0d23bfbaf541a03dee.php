<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\youco\Desktop\hssab-sabon\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>